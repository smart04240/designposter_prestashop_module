<?php
/**
 * designposter
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once dirname(__FILE__) . '/models/DesignPosterModel.php';
class DesignPoster extends Module
{
    protected $id_shop = null;
    protected $id_shop_group = null;
    private $tab_parent_class = null;
    private $tab_class  = 'AdminDesignPoster';
    private $tab_module = 'designposter';

    public function __construct()
    {
        $this->name = 'designposter';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Dovletov';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Custom posters');
        $this->description = $this->l('Display custom design poster orders.');
        $this->ps_versions_compliancy = array('min' => '1.6.0.0', 'max' => _PS_VERSION_);

        if ($this->id_shop === null || !Shop::isFeatureActive()) {
            $this->id_shop = Shop::getContextShopID(true);
        } else {
            $this->id_shop = $this->context->shop->id;
        }

        if ($this->id_shop_group === null || !Shop::isFeatureActive()) {
            $this->id_shop_group = Shop::getContextShopGroupID();
        } else {
            $this->id_shop_group = $this->context->shop->id_shop_group;
        }
    }

    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        if (!$this->existsTab($this->tab_class)) {
            if (!$this->addTab($this->tab_class, (int) Tab::getIdFromClassName('AdminParentOrders'))) {
                return false;
            }
        }
        
        return parent::install() && DesignPosterModel::scSpecificProductCreateTable();
    }

    public function uninstall()
    {
        if (!$this->removeTab($this->tab_class)) {
            return false;
        }

        if (parent::uninstall() && DesignPosterModel::scSpecificProductDropTable()) {
            return true;
        }
        
        return false;
    }

    private function addTab($tab_class, $id_parent)
    {
        $tab = new Tab();
        $tab->class_name = $tab_class;
        $tab->id_parent = $id_parent;
        $tab->module = $this->tab_module;
        $tab->name[(int)(Configuration::get('PS_LANG_DEFAULT'))] = $this->l('Custom posters');
        if (true === Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=')) {
            $tab->icon = 'tune';
        }
        return $tab->add();
    }

    private function removeTab($tab_class)
    {
        $idTab = Tab::getIdFromClassName($tab_class);
        if ($idTab != 0) {
            $tab = new Tab($idTab);
            $tab->delete();
            return true;
        }

        $idTab1 = Tab::getIdFromClassName('AdminDesignPoster');
        if ($idTab1 != 0) {
            $tab = new Tab($idTab1);
            $tab->delete();
            return true;
        }
    }

    private function existsTab($tab_class)
    {
        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('SELECT id_tab AS id
            FROM `'._DB_PREFIX_.'tab` t WHERE LOWER(t.`class_name`) = \''.pSQL($tab_class).'\'');
        if (count($result) == 0) {
            return false;
        }
        return true;
    }
}
