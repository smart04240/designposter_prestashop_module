$(document).ready(function () {
  var map = window.gMap;
  var posterData = {
    title: 'HORSENS',
    subtitle: 'DENMARK FROM ABOVE',
    size: '0'
  };
  var designs = [];
  var selectedId = 0;
  
  init();

  $('#btn_send').on('click', function () {
    saveDesign();
  });

  $('#poster_title').on('keyup', function (e) {
    handleInputChange(e);
  });

  $('#poster_subtitle').on('keyup', function (e) {
    handleInputChange(e);
  });

  $('#poster_size').on('change', function (e) {
    handleInputChange(e);
  });

  $(document).on('click', '.design-item', function (e) {
    e.preventDefault();
    displayDesign(e);
  });

  $(document).on('click', '.remove-design', function(e) {
    e.preventDefault();
    removeDesign(e);
  });

  function init() {
    var posterDataDraft = getCookie('luftkunst.dk_custom_poster');
    if(posterDataDraft) {
      posterData = {
        title: posterDataDraft.title,
        subtitle: posterDataDraft.subtitle,
        size: posterDataDraft.size
      }
      map.setZoom(Number(posterDataDraft.zoom));
      map.setCenter({
        lat : Number(posterDataDraft.lat),
        lng : Number(posterDataDraft.lng)
      });
    }

    for (key in posterData) {
      $(`#poster_${key}`).val(posterData[key]);
      $(`.map-${key}`).text(posterData[key]);
    }
    
    if(!customerId) {
      $('#designs_list_container').remove();
    } else {
      getDesigns();
      if(posterDataDraft){
        saveDesign();
      }
    }
  
  }

  function handleInputChange(e) {
    var $target = $(e.target);
    var targetId = e.target.id;
    var targetVal = $target.val() !== '' ? $target.val().trim() : '';

    var targetKey = targetId.substr(7, targetId.length - 1);
    posterData[targetKey] = targetVal;

    if (targetKey !== 'size') {
      $(`.map-${targetKey}`).text(targetVal);
    }
  }

  function saveDesign() {
    var btnSend = $('#btn_send');
    posterData.zoom = map.getZoom();
    posterData.lat = map.getCenter().lat();
    posterData.lng = map.getCenter().lng();
    var action = selectedId ? 'updateDesign' : 'storeDesign';
    
    if(selectedId && posterData.status > 1) {
      alert('Can not update.');
      return;
    }

    if(!customerId) {
      setCookie('luftkunst.dk_custom_poster', posterData, 1);
      window.open(loginUrl + '?back=designposter', '_self');
      return;
    } else {
      var posterDataDraft = getCookie('luftkunst.dk_custom_poster');
      
      posterData = posterDataDraft ? posterDataDraft : posterData;
      setCookie('luftkunst.dk_custom_poster', '', 0);
    }
    
    $.ajax({
      url: gAjaxUrl,
      type: 'POST',
      data: {
        action,
        posterData,
        posterId: selectedId
      },
      dataType: 'JSON',
      cache: false,
      beforeSend: function () {
        btnSend.text(`Sending..`);
        btnSend.attr('disabled', 'disabled');
      },
      success: function (response) {
        btnSend.text('SEND A DESIGN');
        btnSend.removeAttr('disabled');
        
        switch (response.status) {
          case 'success':
            alert('Succes, vi kontakter dig når din plakat er færdig designet.');
            if(response.is_update) {
              designs.forEach(function(item, i) {
                if(Number(item.id_custom_poster) === selectedId) {
                  designs.splice(i, 1, response.row);
                  displayDesigns();
                  return;
                }
              });
            } else {
              designs.unshift(response.row);
            }
            displayDesigns();
            break;
          case 'no_update':
            alert('Can not update.');
            break;
          default:
            alert('Somethings error.');

        }
      },
      complete: function(response) {
        selectedId = 0;
      }
    });
  }

  function getDesigns() {
    $.ajax({
      url: gAjaxUrl,
      type: 'get',
      data: {
        action: 'getDesigns'
      },
      dataType: 'json',
      cache: false,
      success: function (response) {
        if(response.status === 'success') {
          designs = response.designs;
          displayDesigns();
        }
      }
    })
  }

  function displayDesigns() {
    var statuses = ['Non ordered', 'Unread', 'Ready', 'Progress', 'Complete', 'Shipped', 'Canceled'];
    var statusColors = ['badge-secondary', 'badge-danger', 'badge-warning', 'badge-info', 'badge-primary', 'badge-success', 'badge-secondary'];
    var $designsElem = $('#designs_list');
    $designsElem.html('');

    designs.forEach(function(item) {
      var childElem =
        `<li>
          <div class="badge-container"><span class="badge ${statusColors[item.status]}">${statuses[item.status]}</span></div>
          <a href="#" class="design-item" data-id="${item.id_custom_poster}">${item.title}</a>`;

      if(Number(item.status) < 2) {
        childElem += ` | <a href="#" class="remove-design" data-id="${item.id_custom_poster}">&times;</a>`;
      }
      childElem += `</li>`;

      $designsElem.append(childElem);
    });
  }

  function displayDesign(e) {
    var $target= $(e.target);
    selectedId = $target.data('id');

    var item = designs.find(function(design) {
      return Number(design.id_custom_poster) === Number(selectedId);
    });
    
    $('.selected').removeClass('selected');
    $target.addClass('selected');

    posterData = {...item};
    
    if(posterData.status > 1) {
      $('#btn_send').attr('disabled', 'disabled');
    }

    for (key in item) {
      $(`#poster_${key}`).val(item[key]);
      $(`.map-${key}`).text(item[key]);
    }
    
    map.setZoom(Number(item.zoom));
    map.setCenter({
      lat : Number(item.lat),
      lng : Number(item.lng)
    });
  }

  function removeDesign(e) {
    var $target = $(e.target);
    var id = Number($target.data('id'));
    
    if(Number(selectedId) === id) {
      selectedId = 0;
    }

    if(posterData.status > 1) {
      alert('Can not delete.');
      return;
    }

    $.ajax({
      url: gAjaxUrl,
      type: 'post',
      data: {
        action: 'removeDesign',
        id
      },
      dataType: 'json',
      cache: false,
      success: function (response) {
        switch (response.status) {
          case 'not_owner':
            alert('Can not delete.');
            break;
          case 'success':
            designs.forEach(function(item, i) {
              if(Number(item.id_custom_poster) === id) {
                designs.splice(i, 1);
                displayDesigns();
                return;
              }
            });
            break;
          case 'no_delete':
            alert('Can not delete.');
            break;
          default:
            alert('Somethings error. Please again.');
        }
      }
    })
  }

  function setCookie(cname, cvalue, exdays) {
    cvalue = typeof(cvalue) === 'string' ? cvalue : JSON.stringify(cvalue);
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  
  function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        var cvalue = c.substring(name.length, c.length);
        return JSON.parse(cvalue);
      }
    }
    return "";
  }
});