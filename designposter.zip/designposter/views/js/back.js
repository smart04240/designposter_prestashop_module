$(document).ready(function () {
  var statuses = ['Non ordered', 'Unread', 'Ready', 'Progress', 'Complete', 'Shipped', 'Canceled'];
  var statusColors = ['btn-secondary', 'btn-danger', 'btn-warning', 'btn-info', 'btn-primary', 'btn-success', 'btn-secondary'];

  getData();

  $(document).on('click', '.btn-status', function (e) {
    saveStatus(e);
  });

  function init(data) {
    $('#map_title').text(data.title);
    $('#info_title').text(data.title);
    $('#map_subtitle').text(data.subtitle);
    $('#info_subtitle').text(data.subtitle);
    $('#info_size').text(getPosterSize(data.size));

    displayStatus(data.status);
    map.setZoom(Number(data.zoom));
    map.setCenter({
      lat : Number(data.lat),
      lng : Number(data.lng)
    });
  }

  function getPosterSize(sizeCode) {
    switch (Number(sizeCode)) {
      case 0:
        return '20x30 cm';
      case 1:
        return '30x40 cm';
      case 2:
        return '50x70 cm';
      default:
        return 'Unknown';
    }
  }

  function displayStatus(status) {
    status = Number(status);
    var currentStatusElem = $('#poster_status');
    
    if(status === 0) {
      currentStatusElem.text('Non ordered');
      currentStatusElem.addClass('btn btn-secondary');  
      currentStatusElem.attr('disabled', 'disabled');
      return;
    }

    var statusList = getStatus(status);
    currentStatusElem.removeClass();
    currentStatusElem.text(statusList.current.status);
    currentStatusElem.addClass(statusList.current.color + ' btn dropdown-toggle');
    currentStatusElem.removeAttr('disabled');
    

    var statusListElem = $('#status_list');
    statusListElem.html('');
    statusList.list.forEach(function (item) {
      statusListElem.append(`<button class="dropdown-item btn btn-status">${item}</button>`);
    });
  }

  function getStatus(status) {
    var result = {};
    var statusList = statuses.slice(0);

    var current = {
      status: statusList[status],
      color: statusColors[status]
    };

    statusList.splice(status, 1);
    statusList.splice(0, 1);
    result['current'] = current;
    result['list'] = statusList;

    return result;
  }

  function getData() {
    if (!ajaxUrl) {
      return;
    }

    $.ajax({
      url: ajaxUrl,
      type: 'get',
      data: {
        action: 'getPoster',
        posterId
      },
      dataType: 'json',
      cache: false,
      success: function (response) {
        init(response.data);
      }
    });
  }

  function saveStatus(e) {
    var $target = $(e.target);
    var statusCode = getStatusCode($target.text());
    
    if (!ajaxUrl) {
      return;
    }
    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'updateStatus',
        statusCode,
        posterId
      },
      dataType: 'JSON',
      cache: false,
      beforeSend: function () {
        var currentStatusElem = $('#poster_status');
        currentStatusElem.text(`Saving..`);
        currentStatusElem.attr('disabled', 'disabled');
      },
      success: function (response) {
        if (response.status === 'invalid') {
          alert('Somethings wrong! Please again.');
        }

        if (response.status === 'error') {
          alert('Server error! Please again.');
        }

        if (response.status === 'success') {
          displayStatus(response.statusCode);
        }
      },
    });
  }

  function getStatusCode(statusText) {
    var statusCode = statuses.findIndex(function (item) {
      return item.toLowerCase() === statusText.toLowerCase();
    });

    return statusCode ? Number(statusCode) : undefined;
  }
});