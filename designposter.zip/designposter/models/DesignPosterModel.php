<?php

/**
 * Class DesignPoster.
 */
class DesignPosterModel extends ObjectModel
{
    /** @var int Poster ID */
    public $id;

    /** @var int Customer ID */
    public $id_customer;

    /** @var int Guest ID */
    public $id_guest;

    /** @var string Poster title */
    public $title;

    /** @var string Poster subtitle */
    public $subtitle;

    /** @var int Poster size 0:20*30, 1:30*40, 2:50*70 */
    public $size;

    /** @var float map lat */
    public $lat;

    /** @var float map lng */
    public $lng;

    /** @var int map zoom */
    public $zoom;

    /** @var bool unread */
    public $is_unread;

    /** @var bool complete */
    public $is_complete;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => 'custom_poster',
        'primary' => 'id_custom_poster',
        'fields' => [
            'id_customer' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'id_guest' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'title' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'required' => true],
            'sub_title' => ['type' => self::TYPE_STRING, 'validate' => 'isGenericName'],
            'size' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'lat' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true],
            'lng' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat', 'required' => true],
            'zoom' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'status' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool'],
        ],
    ];

    public function __construct($id = null)
    {
        parent::__construct($id);
    }

    public function scSpecificProductCreateTable()
    {
        return Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'custom_poster`  (
            `id_custom_poster` int(11) NOT NULL AUTO_INCREMENT,
            `id_customer` int(11) NOT NULL DEFAULT 0 COMMENT "customer id",
            `id_guest` int(11) NOT NULL COMMENT "customer id",
            `title` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "poster title",
            `subtitle` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "poster subtitle",
            `size` int(5) NOT NULL DEFAULT 0 COMMENT "poster size 0:20*30 1:30*40 2:50*70",
            `lat` double NOT NULL COMMENT "map lat",
            `lng` double NOT NULL COMMENT "map lng",
            `zoom` int(5) NOT NULL COMMENT "map zoom",
            `status` tinyint(1) DEFAULT 0,
            `date_add` datetime(0) NOT NULL,
            PRIMARY KEY (`id_custom_poster`) USING BTREE,
            INDEX `customer_poster`(`id_customer`) USING BTREE
          ) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;
          
          SET FOREIGN_KEY_CHECKS = 1;');
    }

    public function scSpecificProductDropTable()
    {
        return Db::getInstance()->execute('DROP TABLE IF EXISTS '._DB_PREFIX_.'custom_poster');
    }

    /**
     * Add new poster
     * 
     * @param object $poster
     * @param int $customerId
     */
    public static function addRow($poster, $guestId, $customerId = 0)
    {
        $db = \Db::getInstance();

        $status = !!$customerId ? 1 : 0;
        $data = array(
            'id_customer' => $customerId,
            'id_guest' => $guestId,
            'title' => $poster['title'],
            'subtitle' => $poster['subtitle'],
            'size' => $poster['size'],
            'lat' => $poster['lat'],
            'lng' => $poster['lng'],
            'zoom' => $poster['zoom'],
            'status' => $status,
            'date_add' => date('Y-m-d H:i:s'),
        );

        $db->insert('custom_poster', $data);
        
        $request = 'SELECT * FROM '._DB_PREFIX_.'custom_poster ORDER BY id_custom_poster DESC';
        $result = $db->getRow($request);

        return $result;
    }

    public static function getRowById($id)
    {
        $db = \Db::getInstance();

        $sql = new DbQuery();
        $sql->select('*');
        $sql->from('custom_poster', 'CP');
        $sql->where('CP.id_custom_poster = '.$id);
        return $db->getRow($sql);
    }

    public static function getRowsByUser($guestId, $customerId = null)
    {
        $db = \Db::getInstance();

        $sql = new DbQuery();
        $sql->select('*');
        $sql->from('custom_poster', 'CP');

        if($customerId) {
            $sql->where('CP.id_customer = '.$customerId.' OR CP.id_guest = '.$guestId);
        } else {
            $sql->where('CP.id_guest = '.$guestId);
        }

        $sql->orderBy('status, id_custom_poster DESC');
        return $db->executeS($sql);
    }

    public static function updateById($id, $data = array(), $customerId = null)
    {
        $db = \Db::getInstance();
        
        if($customerId && (int)$customerId !== 0) {
            $data['status'] = 1;
            $data['id_customer'] = $customerId;
        }

        return $db->update('custom_poster', $data, 'id_custom_poster = '.$id, 1, true);
    }

    public static function removeRowById($id)
    {
        $db = \Db::getInstance();

        return $db->delete('custom_poster', 'id_custom_poster = '.$id, 1, true);
    }
}
