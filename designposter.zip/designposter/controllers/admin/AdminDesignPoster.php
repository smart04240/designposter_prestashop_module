<?php
/**
 * designposter
 */
require_once _PS_MODULE_DIR_ . 'designposter/models/DesignPosterModel.php';
class AdminDesignPosterController extends ModuleAdminController
{
    private $_object = null;
    
    public function __construct()
    {
        $this->model = new DesignPosterModel();
        $this->table = 'custom_poster';
        $this->className = 'DesignPosterModel';
        $this->identifier = 'id_custom_poster';

        $this->bootstrap = true;
        parent::__construct();
        $this->context = Context::getContext();
        
        $this->_select .= 'C.id_customer AS id_customer';
        $this->_join .= 'LEFT JOIN `'._DB_PREFIX_.'customer` AS C ON (a.`id_customer` = C.`id_customer`)';
        $this->_orderBy = 'status';
        $this->_orderWay = 'ASC';
        $this->fields_list = array(
            'id_custom_poster' => array(
                'title' => 'ID',
                'width' => 50,
                'filter_key' => 'id_custom_poster',
                'serch' => true,
            ),
            'title' => array(
                'title' => $this->module->l('Title'),
                'width' => 'auto',
                'serch' => true,
            ),
            'id_customer' => array(
                'title' => $this->module->l('Customer'),
                'width' => 150,
                'callback' => 'formatCustomerName',
                'serch' => true,
            ),
            'status' => array(
                'title' => $this->module->l('Status'),
                'width' => 100,
                'callback' => 'formatStatus',
                'serch' => true,
            ),
            'date_add' => array(
                'title' => $this->module->l('Date'),
                'width' => 'auto',
                'serch' => true,
            )
        );

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?')
            )
        );
    }

    public function renderList()
    {
        $this->addCSS(_PS_MODULE_DIR_.'designposter/views/css/back.css');
        $this->addRowAction('view');
        $this->addRowAction('delete');
        return parent::renderList();
    }

    public function initToolbar()
    {
        parent::initToolbar();
        unset($this->toolbar_btn['new']);
    }

    public function formatCustomerName($customerId)
    {
        $sql = new DbQuery();
        $sql->select('CONCAT(LEFT(firstname, 1), \'. \', lastname) AS customer');
        $sql->from('customer');
        $sql->where('id_customer = ' . $customerId);
        $result = Db::getInstance()->executeS($sql);
        $customerName = '';

        if($result) {
            $customerName = $result[0]['customer'];
        }
        return '<a href="'.$this->getCustomerUrl($customerId).'">'.$customerName.'</a>';
    }

    public function getCustomerUrl($customerId)
    {
        
        $customerLink = $this->context->link->getAdminLink('AdminCustomers');
        $customerLinkArr = explode('?_token=', $customerLink);

        $customerUrl = $customerLinkArr[0];
        $token = $customerLinkArr[1];

        return $customerUrl . $customerId . '/view?_token=' . $token;
    }

    public function formatStatus($statusCode)
    {
        $statuses = array('Non ordered', 'Unread', 'Ready', 'Progress', 'Complete', 'Shipped', 'Canceled');
        $badgeColors = array('badge-secondary', 'badge-danger', 'badge-warning', 'badge-info', 'badge-primary', 'badge-success', 'badge-secondary');
        $text = $statuses[$statusCode];
        $badgeColor = $badgeColors[$statusCode];

        return '<span class="badge ' . $badgeColor . '">' . $text . '</span>';
    }

    public function renderView()
    {
        
        $this->addCSS(_PS_MODULE_DIR_.'designposter/views/css/back.css');
        $this->addJS(_PS_MODULE_DIR_.'designposter/views/js/back.js');
        $this->context->smarty->assign(array(
            'path' => 'admindesignposter',
            'ajax_link' => $this->context->link->getAdminLink('AdminDesignPoster'),
            'poster_id' => $this->object ? $this->object->id : 0
        ));
        $this->_object = $this->context->controller->object;
        
        $tpl = $this->context->smarty->createTemplate(_PS_MODULE_DIR_.'designposter/views/templates/admin/designposter/helpers/view/view.tpl');
        return $tpl->fetch();
    }

    public function displayAjaxGetPoster()
    {   
        $posterId = Tools::getValue('posterId');

        $result = $this->model->getRowById($posterId);
        
        $response = array(
            'data' => $result,
            'status' => 'OK'
        );
        header('Content-Type: application/json');
        die(Tools::jsonEncode($response));
    }

    public function displayAjaxUpdateStatus()
    {
        $posterId = Tools::getValue('posterId');
        $status = Tools::getValue('statusCode');

        header('Content-Type: application/json');

        if(!$posterId && !$status) {
            die(Tools::jsonEncode(['status' => 'invalid']));
        }
        
        $result = $this->model->UpdateById($posterId, array('status' => $status));

        if(!$result) {
            die(Tools::jsonEncode(['status' => 'error']));
        }

        die(Tools::jsonEncode([
            'status' => 'success',
            'statusCode' => $status
        ]));
    }
}
