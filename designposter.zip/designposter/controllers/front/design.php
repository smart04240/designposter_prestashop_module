<?php

require_once _PS_MODULE_DIR_ . 'designposter/models/DesignPosterModel.php';

class DesignPosterDesignModuleFrontController extends ModuleFrontController
{
  public function __construct()
  {
    parent::__construct();
    $this->model = new DesignPosterModel();
    $this->customerId = $this->context->customer->id;
    $this->guestId = $this->context->customer->id_guest;
  }


  /**
   * Initialize design controller
   */

  public function init()
  {
    parent::init();
    $this->display_column_left = false;
    $this->display_column_right = false;
  }
  
  public function setMedia()
  {
    parent::setMedia();
  }


  public function initContent()
  {
    parent::initContent();

    $this->addCSS(_PS_MODULE_DIR_.'designposter/views/css/front.css');
    $this->addJS(_PS_MODULE_DIR_.'designposter/views/js/front.js');
    
    $this->context->smarty->assign(array(
      'path' => 'design',
      'ajax_link' => $this->context->link->getModuleLink('designposter', 'design', [], true),
      'customer_id' => $this->customerId,
      'login_url' => $this->context->link->getPageLink('authentication', true),
      
    ));

    $this->setTemplate('module:designposter/views/templates/front/design.tpl');
  }

  public function displayAjaxGetDesigns()
  {
    $data = $this->model->getRowsByUser($this->guestId, $this->customerId);
    header('Content-Type: application/json');
    
    if($data) {
      die(Tools::jsonEncode([
        'status'=> 'success',
        'designs' => $data
      ]));
    }

    die(Tools::jsonEncode(['status'=> 'no_data']));
  }

  public function displayAjaxStoreDesign()
  {
    $poster = Tools::getValue('posterData');

    $customerId = $this->customerId ? $this->customerId : 0;

    header('Content-Type: application/json');
    
    $result = $this->model->addRow($poster, $this->guestId, $customerId);
    
    if($result) {
      die(Tools::jsonEncode([
        'status'=> 'success',
        'row' => $result
      ]));
    }

    die(Tools::jsonEncode(['status' => 'error']));
  }

  public function displayAjaxUpdateDesign()
  {
    $poster = Tools::getValue('posterData');
    $posterId = Tools::getValue('posterId');
    $result = null;
    header('Content-Type: application/json');
    
    if(!$this->isOwner($posterId)) {
      die(Tools::jsonEncode(['status' => 'not_owner']));
    }
    
    $row = $this->model->getRowById($posterId);
    if($row['status'] > 1) {
      die(Tools::jsonEncode(['status' => 'no_update']));
    }
    
    $result = $this->model->updateById($posterId, $poster, $this->customerId);
    
    if($result) {
      die(Tools::jsonEncode([
        'status'=> 'success',
        'row' => $this->model->getRowById($posterId),
        'is_update' => true
      ]));
    }

    die(Tools::jsonEncode(['status' => 'error']));
  }

  public function displayAjaxRemoveDesign()
  {
    $id = Tools::getValue('id');
    
    $row = $this->model->getRowById($id);
    $result = '';

    if(!$this->isOwner($id)) {
      $result = 'not_owner';
    }

    $row = $this->model->getRowById($id);
    if($row['status'] > 1) {
      die(Tools::jsonEncode(['status' => 'no_delete']));
    }

    if ($result !== 'not_owner') {
      $result = $this->model->removeRowById($id);
    }

    header('Content-Type: application/json');
    
    if($result === 'not_owner') {
      die(Tools::jsonEncode(['status'=> 'not_owner']));
    }

    if($result) {
      die(Tools::jsonEncode(['status'=> 'success']));
    }

    die(Tools::jsonEncode(['status' => 'error']));
  }

  public function isOwner($posterId)
  {
    $row = $this->model->getRowById($posterId);
    
    if((int)$row['id_guest'] === (int)$this->guestId || (int)$row['id_customer'] === (int)$this->customerId) {
      return true;
    }

    return false;
  }
}